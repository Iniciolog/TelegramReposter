import express, { type Request, Response, NextFunction } from "express";
import { WebSocketServer } from "ws";
import { createServer } from "http";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const httpServer = createServer(app);
  const server = await registerRoutes(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer });
  
  // Store WebSocket server in app locals for access from other modules
  app.locals.wss = wss;
  
  // Initialize WebSocket service
  const { webSocketService } = await import("./services/websocketService");
  webSocketService.initialize(wss);
  
  wss.on('connection', (ws) => {
    log('📱 WebSocket client connected');
    
    ws.on('close', () => {
      log('📱 WebSocket client disconnected');
    });
    
    ws.on('error', (error) => {
      log('📱 WebSocket error:', String(error));
    });
  });
  
  // Lazy initialization flags
  let servicesInitialized = false;
  
  // Lazy initialize services on first request
  const initializeServices = async () => {
    if (servicesInitialized) return;
    servicesInitialized = true;
    
    try {
      log("🔧 Starting background services...");
      
      // Start web channel parsing service
      const { webChannelParserService } = await import("./services/webChannelParser");
      webChannelParserService.startParsing().catch(err => log("Web channel parser error:", String(err)));

      // Start web source parsing service
      const { webSourceParserService } = await import("./services/webSourceParser");
      webSourceParserService.startParsing().catch(err => log("Web source parser error:", String(err)));

      // Start scheduler service
      const { schedulerService } = await import("./services/scheduler");
      schedulerService.startMonitoring().catch(err => log("Scheduler error:", String(err)));
      
      // Initialize Telegram bot if settings exist
      try {
        const { storage } = await import("./storage");
        const { telegramService } = await import("./services/telegram");
        
        const settings = await storage.getSettings();
        if (settings?.botToken) {
          const success = await telegramService.initializeBot(settings.botToken);
          if (success) {
            await telegramService.startPolling(async (message) => {
              // Handle new message from monitored channels
              const channelPairs = await storage.getChannelPairs();
              
              const matchingPairs = channelPairs.filter(pair => {
                // Remove @ symbol for comparison if present
                const sourceUsername = pair.sourceUsername.replace('@', '');
                const messageUsername = message.chat.username;
                
                const sourceMatch = sourceUsername === messageUsername;
                return sourceMatch && pair.status === 'active';
              });
              
              for (const pair of matchingPairs) {
                try {
                  // Create post record
                  const post = await storage.createPost({
                    channelPairId: pair.id,
                    originalPostId: message.message_id.toString(),
                    content: message.text || message.caption || '',
                    mediaUrls: message.photo ? [message.photo[message.photo.length - 1].file_id] : [],
                    status: 'pending',
                  });

                  // Log activity
                  await storage.createActivityLog({
                    type: 'post_detected',
                    description: `New post detected from ${pair.sourceName}`,
                    channelPairId: pair.id,
                    postId: post.id,
                  });
                } catch (error) {
                  log("Error processing message:", String(error));
                }
              }
            });
          }
        }
      } catch (error) {
        log("Failed to initialize bot:", String(error));
      }
      
      log("✅ Background services started");
    } catch (error) {
      log("⚠️ Error starting services:", String(error));
    }
  };
  
  // Middleware to trigger lazy initialization on first request
  app.use((req, res, next) => {
    initializeServices().catch(err => log("Service init error:", String(err)));
    next();
  });

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }


  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  httpServer.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
